<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="no-js ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="no-js ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="no-js ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en" class="no-js"> <!--<![endif]-->
<head>

	<!-- Basic Page Needs
  	================================================== -->
	<meta charset="utf-8" />
	<title>Donia Samir Ghanem Official Website :: Gallery Page</title>
	<meta name="description" content="" />
	<meta name="author" content="" />

	<!-- Mobile Specific Metas
  	================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<!-- CSS
  	================================================== -->
	<link rel="stylesheet" href="css/normalize.css" />

	<!-- Bootstrap -->
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="css/bootstrap-responsive.css" />

	<!-- BX Slider -->
	<link rel="stylesheet" href="css/jquery.bxslider.css" />

	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

	<!-- Icons -->
	<link rel="stylesheet" href="css/font/fontello.css" />
    <!--[if IE 7]>
    <link rel="stylesheet" href="css/font/fontello-ie7.css"><![endif]-->

    <!-- Monkey Styles -->
	<link rel="stylesheet" href="css/style.css" />

	<!-- JS
  	================================================== -->
    <script src="js/modernizr.custom.85650.js"></script>

	<!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="images/icons/favicon.ico" />
	<link rel="apple-touch-icon" href="images/icons/apple-touch-icon.png" />
	<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png" />
	<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png" />

<script src='/google_analytics_auto.js'></script><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
<body>

	<div id="container" class="mk-container">

        <!-- menu panel -->
		<div class="menu-panel" style="
    box-shadow: 1px 5px 14px rgb(0, 0, 0);
    box-shadow: #000;
">

        	<!-- brand -->
			<h1 id="brand"><a href="index.html"><img src="images/logo/logo.png" alt="Monky" /></a></h1>
			<!-- end brand -->

            <!-- menu -->
            <ul id="menu-toc" class="menu-toc">
				<li><a href="index.html">Home</a></li>
				<li><a href="biography.html">Biography</a></li>
				<li><a href="discography.html">Discography</a></li>
				<li><a href="filmography.html">Filmography</a></li>
				<li><a href="gallery.php">Gallery</a></li>
						<li><a href="b2.html">Videos</a></li>
                <li><a href="contact.php">Contact us</a></li>
			</ul>
            <!-- end menu -->

			<select id="mselect" name="mselect" onchange="location = this.options[this.selectedIndex].value;">

				<option value="" selected="" />Select Page

				<option value="index.html" />Home

				<option value="biography.html" />Biography

				<option value="discography.html" />Discography

				<option value="filmography.html" />Filmography

				<option value="b2.html" />Videos



				<option value="gallery.php" />Gallery

				<option value="contact.php" />Contact us

			</select>

            <!-- social icons -->
			<div class="social clearfix" style="text-align: center;padding-left:0px;">


				<h4>Stay <strong>Connected</strong></h4>
<a href="http://www.facebook.com/DoniaSamirGhanem" target="_blank"><img src="ff.png" alt="Facebook" border="0" width="35"></a>
<a href="https://twitter.com/Donia/" target="_blank"><img src="tt.png"  alt="Twitter" border="0" width="35"></a>
<a href="https://plus.google.com/117594584520693408962" target="_blank"><img src="gg.png"  alt="Google Plus" border="0" width="35"></a>
<a href="http://youtube.com/Doniasamirghanem" target="_blank"><img src="yy.png" alt="Youtube" border="0" width="35"></a>


			</div>
            <!-- end social icons -->

			<!-- credits -->
			<div class="credits">
					<p style="font-size:15px">&copy; 2015 <a style="color:#FFD700;" target="_blank" href="http://roznamaonline.com">Roznama Online</a></p>
			</div>
            <!-- end credits -->

		</div>
        <!-- end menu panel -->


		<div class="bb-custom-wrapper">
			<div class="bigphotos gallery gallery-3-cols box">
				<div class="wrapper"  style=" left:62%;  background:url(images/bk.png) repeat; -webkit-border-radius: 10px; -moz-border-radius: 10px; border-radius: 10px;">

	            	<h1>Donia <small>Gallery</small></h1>

	            	<div class="gallery-grid">

	            		<div id="category-1">
		            		<ul id="gallery-slider-1" class="gallery-3-cols-slider">

								
								<li>
					            			            			<div class="row-fluid">
								
					            		<div class="span4">
											<article class="gallery-item">
												<a href="galleryin.php?id=2">
													<div class="thumbnail-overlay"></div>
													<img src="img/album/Untitled-1 dodoy.jpg"  width="284" height="152" alt="Donia's Album Signature" />
												</a>
												<div class="gallery-description">
													<h2 class="item-title"><a href="galleryin.php?id=2">Donia's Album Signature</a></h2>
												</div>
											</article>
					            		</div>
                                         
					            		<div class="span4">
											<article class="gallery-item">
												<a href="galleryin.php?id=4">
													<div class="thumbnail-overlay"></div>
													<img src="img/album/392 copy.JPG"  width="284" height="152" alt="El Kebeer" />
												</a>
												<div class="gallery-description">
													<h2 class="item-title"><a href="galleryin.php?id=4">El Kebeer</a></h2>
												</div>
											</article>
					            		</div>
                                         
					            		<div class="span4">
											<article class="gallery-item">
												<a href="galleryin.php?id=6">
													<div class="thumbnail-overlay"></div>
													<img src="img/album/main.jpg"  width="284" height="152" alt="Donia & Ramy's Wedding Party" />
												</a>
												<div class="gallery-description">
													<h2 class="item-title"><a href="galleryin.php?id=6">Donia & Ramy's Wedding Party</a></h2>
												</div>
											</article>
					            		</div>
                                         


									</div>
				            			<div class="row-fluid">
								
					            		<div class="span4">
											<article class="gallery-item">
												<a href="galleryin.php?id=7">
													<div class="thumbnail-overlay"></div>
													<img src="img/album/Main11.jpg"  width="284" height="152" alt="Donia & Ramy's Engagement" />
												</a>
												<div class="gallery-description">
													<h2 class="item-title"><a href="galleryin.php?id=7">Donia & Ramy's Engagement</a></h2>
												</div>
											</article>
					            		</div>
                                         


									</div>
		
		            			</li>

		            				            		</ul>  <!-- #gallery-slider-1 -->
	            		</div>  <!-- .category-1 -->

	            		  <!-- .category-2 -->

	            		 <!-- .category-3 -->

	             <!-- .nav-pills -->

	            	</div> <!-- .gallery-grid -->

				</div> <!-- .wrapper -->
            </div> <!-- .bigphotos .members -->

			<span id="tblcontents" style="background-color:#d12f4f;" class="menu-button">Table of Contents</span>

		</div> <!-- .bb-custom-wrapper -->

	</div><!-- /container -->


    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.1.min.js"><\/script>')</script>

	<script src="js/jquery.bxslider.min.js"></script>

    <script src="js/bootstrap.min.js"></script>

    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    <script>
		$(function() {

			Page.init();

		});
	</script>

</body>
</html>